function getProfiles(){
    const xhr = new XMLHttpRequest();

    xhr.open('GET','http://192.168.100.10:5000/Admin',true);

    xhr.onload = function(){
  if(this.status === 200){
      
      data = JSON.parse(this.responseText);
      data.forEach(function(user){
        output += `
        
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">${user.name}</h5>
            <p class="card-text">${user.email}</p>
            <p class="card-text">${user.id}</p>
            <button class="btn btn-primary" id="deletePost" onclick='deletePost(${user.id})' ">Delete</button>
            <button class="btn btn-primary" id="updatePost" onclick='updatePost()' ">updatepost</button>
          </div>
        </div>
        `;
      }
    );
      document.getElementById('output').innerHTML = output;
  
  }
  

}

xhr.send();
}
function deletePost(sus_id){
   
var url = "http://192.168.100.10:5000/";
var xhr = new XMLHttpRequest();
xhr.open("DELETE", url+`/${sus_id}`, true);
xhr.onload = function () {
  var users = JSON.parse(JSON.stringify(xhr.responseText));
  if (xhr.readyState == 4 && xhr.status == "200") {
        console.log('users');
        const obj = document.querySelector('#deletePost');
        obj.parentElement.parentElement.remove();
  } else {
    console.log(users);
    }
    
}
xhr.send(null);
s = document.querySelector('#deletePost');
s.parentElement.parentElement.remove();
}
function updatePost(){
    s = document.querySelector('#updatePost');
    s.parentElement.parentElement.remove();
}

document.querySelector('body').addEventListener('DOMContentLoaded',getProfiles());