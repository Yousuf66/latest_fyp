let ip; 
export default ip = 'your ip here'; 