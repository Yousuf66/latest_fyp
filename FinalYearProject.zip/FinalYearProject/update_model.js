
function updateModel(){

    // let ip = '192.168.43.168:5000';
    
      const xhr = new XMLHttpRequest();
  
      xhr.open('GET','http://192.168.43.168:5000/cam',true);
  
      xhr.onload = function(){
    if(this.status === 200){
      
        res = JSON.parse(this.responseText);
        console.log(res);
      
    }
    
  
  }
  
   xhr.send();
  }