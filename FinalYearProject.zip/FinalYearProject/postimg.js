//fetch using a Request and a Headers objects
// uploading an image along with other POST data
//using jsonplaceholder for the data

const url = 'http://192.168.100.9:5000/image';

document.addEventListener('DOMContentLoaded', init);

function init(){
    document.getElementById('Submit').addEventListener('click', upload);
}

function upload(ev){
    ev.preventDefault();    //stop the form submitting

    //create any headers we want
    let h = new Headers();
    h.append('Accept', 'application/json'); //what we expect back
    //bundle the files and data we want to send to the server
    let fd = new FormData();
    fd.append('user-id', document.getElementById('user_id').value);
    
    let myFile = document.getElementById('image').files[0];
    fd.append('image', myFile, "avatar.png");
    // $_FILES['avatar']['file_name']  "avatar.png"
    let req = new Request(url, {
        method: 'POST',
        headers: h,
        mode: 'no-cors',
        body: fd
    });

    fetch(req)
        .then( (response)=>{
            console.log('done bitch');
        })
        .catch( (err) =>{
            console.log('ERROR:', err.message);
        });
}