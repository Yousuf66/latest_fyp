ip ='http://192.168.100.9:5000'
function userLogin(e){

var form = document.getElementById('user-login');
var formData = new FormData(form);



    const xhr = new XMLHttpRequest();

  xhr.open('POST',ip+'/User/Login',true);

  xhr.onload = function(){
      if(this.status === 200){
        //   data = console.log(this.responseText);
        if(this.responseText == 'Successfully logged in'){
            window.location.replace('SuspectRecord.html');
        }else{
            console.log('bad');
        }
      }
  }

 
xhr.send(formData);

}

function adminLogin(){

var form = document.getElementById('admin-login');
var formData = new FormData(form);
const xhr = new XMLHttpRequest();

  xhr.open('POST',ip+'/Admin/Login',true);

  xhr.onload = function(){
      if(this.status === 200){
        //   data = console.log(this.responseText);
        if(this.responseText == 'Successfully logged in'){
            window.location.replace('SuspectRecord.html');
        }else{
            console.log('bad');
        }
      }
  }

 
xhr.send(formData);

}